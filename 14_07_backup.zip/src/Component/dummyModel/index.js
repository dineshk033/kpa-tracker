import React from "react";

const image =
  "https://wallpaper-mania.com/wp-content/uploads/2018/09/High_resolution_wallpaper_background_ID_77700505645.jpg";
export const DummyModel = () => {
  // return <img src={image} alt="avanger" height='100%' width='100%'/>
  return <img src={image} alt="avanger" height="100%" width="100%" />;
};
